#include "arvore.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "impressao.h"

void alocarArvore(No **ppRaiz)
{
    *ppRaiz = NULL;
}

void desalocarArvore(No **ppRaiz)
{
    liberaArvore(ppRaiz);
    *ppRaiz = NULL;
}

void liberaArvore(No **ppRaiz)
{
    if (*ppRaiz != NULL)
    {
        liberaArvore(&(*ppRaiz)->pEsq); // Desaloca subárvore esquerda
        liberaArvore(&(*ppRaiz)->pDir); // Desaloca subárvore direita
        free(*ppRaiz);                  // Desaloca o nó atual
        *ppRaiz = NULL;
    }
}

No *NoCria(No x)
{

    No *novoNo = (No *)malloc(sizeof(No));
    if (novoNo != NULL)
    {
        novoNo->pessoa = x.pessoa;
        novoNo->cor = RED; // Por padrão, um novo nó é sempre RED
        novoNo->pPai = NULL;
        novoNo->pEsq = NULL;
        novoNo->pDir = NULL;
    }
    return novoNo;
}
void leArvore(Arvore *pRaiz, int n)
{
    No temp;
    for (int i = 0; i < n; i++)
    {
        scanf("%s%d", temp.pessoa.nome, &temp.pessoa.idade);
        insercao(pRaiz, &temp);
    }
}

void rotacaoAEsquerda(No** arvore, No* x) {
    printf("ROTACAO ESQUERDA\n");
    if (x != NULL && x->pDir != NULL) {
        printf("Entrou no if da ESQUERDA\n");
        No* y = x->pDir;
        x->pDir = y->pEsq;

        if(x->pEsq != NULL)          // Caso a direita de X não seja um nó folha (NULL) corrige o parentesco
            x->pEsq->pPai = x;

        y->pPai = x->pPai;

        if (x->pPai == NULL) {
            *arvore = y;
            //printf("Rotação Esquerda - Nova Raiz: %s\n", y->pessoa.nome);
        } else if (x == x->pPai->pEsq) {
            x->pPai->pEsq = y;
           //printf("Rotação Esquerda - Novo Filho Esquerdo de %s: %s\n", x->pPai->pessoa.nome, y->pessoa.nome);
        } else {
            x->pPai->pDir = y;
            //printf("Rotação Esquerda - Novo Filho Direito de %s: %s\n", x->pPai->pessoa.nome, y->pessoa.nome);
        }

        y->pEsq = x;
        x->pPai = y;
        printf("\n\n");
    }
    printRBTreeRecursive(*arvore, 0, "");
}

void rotacaoADireita(No** arvore, No* y) {
    printf("Rotacao Direita\n");
    if (y != NULL && y->pEsq != NULL) {
        No* x = y->pEsq;
        y->pEsq = x->pDir;

        if (y->pDir != NULL) {
            y->pDir->pPai = y;
        }

        x->pPai = y->pPai;

        if (y->pPai == NULL) {
            *arvore = x;
            //printf("Rotação Direita - Nova Raiz: %s\n", x->dado.nome);
        } else if (y == y->pPai->pDir) {
            y->pPai->pDir = x;
            //printf("Rotação Direita - Novo Filho Esquerdo de %s: %s\n", y->pPai->pessoa.nome, x->pessoa.nome);
        } else {
            y->pPai->pEsq = x;
            //printf("Rotação Direita - Novo Filho Direito de %s: %s\n", y->pPai->pessoa.nome, x->pessoa.nome);
        }

        x->pDir = y;
        y->pPai = x;
        printf("\n\n");
    }
    printRBTreeRecursive(*arvore, 0, "");
}


void insercao(No **raiz, No *umValor)
{
    No *novoNoh = NoCria(*umValor);

    if (*raiz == NULL)
    {
        *raiz = novoNoh;
    }
    else
    {
        No *atual = *raiz;
        No *anterior = NULL;

        while (atual != NULL)
        {
            anterior = atual;

            if (atual->pessoa.idade > umValor->pessoa.idade)
            {
                atual = atual->pEsq;
            }
            else
            {
                atual = atual->pDir;
            }
        }

        novoNoh->pPai = anterior;

        if (anterior->pessoa.idade > novoNoh->pessoa.idade)
        {
            anterior->pEsq = novoNoh;
        }
        else
        {
            anterior->pDir = novoNoh;
        }


        // Corrigir as propriedades da árvore red-black após a inserção
        balanceamento(raiz, novoNoh);
    }
}

void balanceamento(No **raiz, No *novo)
{
    printf("Entrou no balanceamento:\n");
    printRBTreeRecursive(*raiz, 0, "");
    No* pai;


    while (novo != *raiz && novo->pPai->cor == RED && novo->cor == RED)
    {
        int rot_dupla2 = 0;
        int rot_dupla1 = 0;
        printf("Entrou no while:\n");
        pai = novo->pPai;
        if(pai->pPai == NULL){
            break;
        }
        
        if (novo->pPai == novo->pPai->pPai->pEsq)
        {
            printf("ENTROU NO IF\n");
            No *tio = novo->pPai->pPai->pDir;
            if (tio != NULL && tio->cor == RED)
            {
                printf("ENTROU NO CASO 1\n");
                pai->cor = BLACK;
                tio->cor = BLACK;          // Caso 1
                novo->pPai->pPai->cor = RED; // Caso 1
                novo = novo->pPai->pPai;     // Caso 1
            }
            else
            {
                if (novo == pai->pDir)
                {
                    printf("ENTROU NO CASO 2\n");
                    novo = pai;             // Caso 2
                    rotacaoAEsquerda(raiz, pai); // Caso 2
                    pai->cor = RED;
                    rot_dupla1++;

                }
                printf("ENTROU NO CASO 3\n");
                if(!rot_dupla1)
                    pai->cor = BLACK;
                novo->pPai->pPai->cor = RED;         // Caso 3
                rotacaoADireita(raiz, novo->pPai->pPai); // Caso 3

            }
        } else {
            printf("Else\n");
            No *tio = novo->pPai->pPai->pEsq;
            if (tio != NULL && tio->cor == RED)
            {
                printf("Caso 1\n");
                pai->cor = BLACK;
                tio->cor = BLACK;          // Caso 1
                novo->pPai->pPai->cor = RED; // Caso 1
                novo = novo->pPai->pPai;     // Caso 1
            }
            else
            {
                if (novo == novo->pPai->pEsq)
                {
                    printf("Caso 2\n");
                    novo = pai;
                    rotacaoADireita(raiz, pai); // Caso 2
                    pai->cor = RED;
                    rot_dupla2++;
                }
                printf("Caso 3\n");
                if(!rot_dupla2)
                    pai->cor = BLACK;
                novo->pPai->pPai->cor = RED;         // Caso 3
                rotacaoAEsquerda(raiz, novo->pPai->pPai); // Caso 3
            }
        }
    }
    (*raiz)->cor = BLACK; // Conserta possível quebra regra 2
}

/*bool balanceamento(No **pRaiz, No *z)
{
    bool rotationPerformed = false;

    while (z != *pRaiz && z->pPai->cor == RED && z->cor == RED)
    {
        if (z->pPai == z->pPai->pPai->pEsq)
        {
            No *y = z->pPai->pPai->pDir;
            if (y->cor == RED)
            {
                z->pPai->cor = BLACK;
                y->cor = BLACK;
                z->pPai->pPai->cor = RED;
                z = z->pPai->pPai;
                rotationPerformed = true;
            }
            else
            {
                // printf("DENTRO DO ELSE\n");
                if (z == z->pPai->pDir)
                {
                    z = z->pPai;
                    rotacaoEsquerda(pRaiz, z);
                    rotationPerformed = true;
                }
                z->pPai->cor = BLACK;
                z->pPai->pPai->cor = RED;
                rotacaoDireita(pRaiz, z->pPai->pPai);
                rotationPerformed = true;
            }
        }
        else if (z->pPai != NULL)
        {
            // printf("DENTRO DO ELSE IF\n");
            No *y = z->pPai->pPai->pEsq;
            if (y != NULL && y->cor == RED)
            {
                z->pPai->cor = BLACK;
                y->cor = BLACK;
                z->pPai->pPai->cor = RED;
                z = z->pPai->pPai;
                rotationPerformed = true;
            }
            else
            {1 
2
Barbara 
24
Vitor
23
2
1
3
Karol
18
Bernardo
12
Marlon
28
0
                if (z == z->pPai->pEsq)
                {
                    z = z->pPai;
                    rotacaoDireita(pRaiz, z);
                    rotationPerformed = true;
                }
                z->pPai->cor = BLACK;
                z->pPai->pPai->cor = RED;
                rotacaoEsquerda(pRaiz, z->pPai->pPai);
                rotationPerformed = true;
            }
        }
    }
    (*pRaiz)->cor = BLACK;

    return rotationPerformed;
}*/

void printInOrder(No *p)
{
    if (p == NULL)
        return;
    if (p != NULL && p->pEsq != NULL)
    {
        printInOrder(p->pEsq);
    }

    printf("Nome: %s\nIdade: %d\n", p->pessoa.nome, p->pessoa.idade);

    if (p != NULL && p->pDir != NULL)
    {
        printInOrder(p->pDir);
    }
}
