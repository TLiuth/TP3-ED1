#ifndef impressao_h
#define impressao_h
#include <stdbool.h>

void printRBTree(No *root, int level);

void printRBTreeRecursive(No *node, int level, const char *edge);



#endif